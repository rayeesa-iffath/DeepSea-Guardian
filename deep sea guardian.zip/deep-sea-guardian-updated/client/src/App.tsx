import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/HomeEnhanced";
import Dashboard from "./pages/DashboardEnhanced";
import Species from "./pages/SpeciesEnhanced";
import Analytics from "./pages/Analytics";
import AlertCenter from "./pages/AlertCenter";
import OceanMap from "./pages/OceanMap";
import Navigation from "./components/Navigation";
import UnderwaterBackground from "./components/UnderwaterBackground";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/dashboard"} component={Dashboard} />
      <Route path={"/species"} component={Species} />
      <Route path={"/analytics"} component={Analytics} />
      <Route path={"/alerts"} component={AlertCenter} />
      <Route path={"/map"} component={OceanMap} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
      >
        <TooltipProvider>
          <UnderwaterBackground />
          <Toaster />
          <Navigation />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
