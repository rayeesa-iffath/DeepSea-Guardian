import { useState } from 'react';
import { motion } from 'framer-motion';
import CircularGallery from '@/components/CircularGallery';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ChevronDown } from 'lucide-react';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

// Mock species data with placeholder images
const speciesData = [
  {
    id: 1,
    name: 'Great White Shark',
    image: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=400&fit=crop',
    confidence: 94,
    status: 'Vulnerable',
    depth: '0-200m',
    region: 'Atlantic & Pacific'
  },
  {
    id: 2,
    name: 'Sea Turtle',
    image: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=400&fit=crop',
    confidence: 89,
    status: 'Endangered',
    depth: '0-1000m',
    region: 'Tropical Waters'
  },
  {
    id: 3,
    name: 'Coral Polyp',
    image: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=400&h=400&fit=crop',
    confidence: 92,
    status: 'Threatened',
    depth: '0-50m',
    region: 'Reef Systems'
  },
  {
    id: 4,
    name: 'Dolphin',
    image: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=400&fit=crop',
    confidence: 96,
    status: 'Vulnerable',
    depth: '0-300m',
    region: 'Global'
  },
  {
    id: 5,
    name: 'Octopus',
    image: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=400&h=400&fit=crop',
    confidence: 87,
    status: 'Stable',
    depth: '0-2000m',
    region: 'Deep Ocean'
  },
  {
    id: 6,
    name: 'Jellyfish',
    image: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=400&fit=crop',
    confidence: 91,
    status: 'Stable',
    depth: '0-4000m',
    region: 'Global'
  }
];

export default function Species() {
  const [selectedSpecies, setSelectedSpecies] = useState<typeof speciesData[0] | null>(null);

  const galleryItems = speciesData.map(species => ({
    image: species.image,
    text: species.name
  }));

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Endangered':
        return 'badge-critical';
      case 'Vulnerable':
      case 'Threatened':
        return 'badge-warning';
      default:
        return 'badge-info';
    }
  };

  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-accent mb-2">
            Species Recognition
          </h1>
          <p className="text-foreground/70 text-lg">
            AI-powered marine biodiversity identification and tracking
          </p>
        </motion.div>

        {/* Gallery Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <Card className="glass p-8 overflow-hidden">
            <h2 className="text-2xl font-bold text-accent mb-6">Marine Species Gallery</h2>
            <p className="text-foreground/70 mb-6">
              Scroll to explore detected marine species. Click on any species to view detailed information.
            </p>
            <div className="h-96 bg-card/50 rounded-lg overflow-hidden">
              <CircularGallery
                items={galleryItems}
                bend={2}
                textColor="#39ff8f"
                borderRadius={0.1}
                font="bold 24px 'Figtree'"
                scrollSpeed={2}
                scrollEase={0.05}
              />
            </div>
          </Card>
        </motion.div>

        {/* Species Details Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {speciesData.map((species) => (
            <motion.div
              key={species.id}
              variants={itemVariants}
              onClick={() => setSelectedSpecies(selectedSpecies?.id === species.id ? null : species)}
              className="cursor-pointer"
            >
              <Card className="glass p-6 h-full hover:shadow-lg hover:shadow-accent/30 transition-all duration-300">
                <div className="mb-4 overflow-hidden rounded-lg h-40">
                  <img
                    src={species.image}
                    alt={species.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>

                <h3 className="text-xl font-semibold text-foreground mb-2">{species.name}</h3>

                <div className="flex items-center justify-between mb-4">
                  <span className={`text-sm px-3 py-1 rounded-full ${getStatusColor(species.status)}`}>
                    {species.status}
                  </span>
                  <span className="text-accent font-semibold">{species.confidence}%</span>
                </div>

                <div className="text-xs text-foreground/60 space-y-1 mb-4">
                  <p><span className="text-accent">Depth:</span> {species.depth}</p>
                  <p><span className="text-accent">Region:</span> {species.region}</p>
                </div>

                <motion.div
                  animate={{ rotate: selectedSpecies?.id === species.id ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                  className="flex items-center justify-center text-accent"
                >
                  <ChevronDown className="h-5 w-5" />
                </motion.div>

                {/* Expanded Details */}
                {selectedSpecies?.id === species.id && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3 }}
                    className="mt-4 pt-4 border-t border-border"
                  >
                    <div className="space-y-3 text-sm">
                      <div>
                        <p className="text-accent font-semibold mb-1">AI Confidence Score</p>
                        <div className="w-full bg-card rounded-full h-2">
                          <div
                            className="bg-accent h-2 rounded-full"
                            style={{ width: `${species.confidence}%` }}
                          />
                        </div>
                      </div>

                      <div>
                        <p className="text-accent font-semibold mb-2">Conservation Status</p>
                        <p className="text-foreground/70">
                          This species is currently listed as <span className="text-accent font-semibold">{species.status}</span> by marine conservation organizations.
                        </p>
                      </div>

                      <div>
                        <p className="text-accent font-semibold mb-2">Habitat Information</p>
                        <p className="text-foreground/70">
                          Typically found at depths of {species.depth} in {species.region}.
                        </p>
                      </div>

                      <div>
                        <p className="text-accent font-semibold mb-2">Detection Method</p>
                        <p className="text-foreground/70">
                          Identified using advanced AI computer vision trained on marine biodiversity datasets.
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Statistics Section */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="mt-12 grid md:grid-cols-3 gap-6"
        >
          <motion.div variants={itemVariants}>
            <Card className="glass p-6 text-center">
              <div className="stat-counter text-4xl mb-2">
                {speciesData.length}
              </div>
              <p className="text-foreground/70">Species Detected</p>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card className="glass p-6 text-center">
              <div className="stat-counter text-4xl mb-2">
                {(speciesData.reduce((sum, s) => sum + s.confidence, 0) / speciesData.length).toFixed(0)}%
              </div>
              <p className="text-foreground/70">Average Confidence</p>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card className="glass p-6 text-center">
              <div className="stat-counter text-4xl mb-2">
                {speciesData.filter(s => s.status !== 'Stable').length}
              </div>
              <p className="text-foreground/70">At-Risk Species</p>
            </Card>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
