import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Droplets, Heart, Trash2, Fish, AlertTriangle } from 'lucide-react';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

// Animated counter component
import { useRef } from 'react';
function AnimatedCounter({ target, duration = 1 }: { target: number; duration?: number }) {
  const [count, setCount] = useState(target);
  const prevTargetRef = useRef(target);

  useEffect(() => {
    const startVal = prevTargetRef.current;
    const endVal = target;
    if (startVal === endVal) return;

    let startTime: number;
    let animationId: number;

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / (duration * 1000), 1);

      setCount(Math.floor(startVal + (endVal - startVal) * progress));

      if (progress < 1) {
        animationId = requestAnimationFrame(animate);
      } else {
        prevTargetRef.current = endVal;
      }
    };

    animationId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationId);
  }, [target, duration]);

  useEffect(() => {
    prevTargetRef.current = target;
  }, []);

  return <span>{count.toLocaleString()}</span>;
}

export default function Dashboard() {
  const [metrics, setMetrics] = useState({
    waterQuality: 78,
    coralHealth: 65,
    plasticDensity: 342,
    marineSpecies: 1247,
    riskIndex: 72
  });

  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-accent mb-2">
            Global Ocean Dashboard
          </h1>
          <p className="text-foreground/70 text-lg">
            Real-time monitoring of ocean health and environmental metrics
          </p>
        </motion.div>

        {/* Key Metrics Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid md:grid-cols-2 lg:grid-cols-5 gap-6 mb-12"
        >
          {/* Water Quality */}
          <motion.div variants={itemVariants}>
            <Card className="glass p-6 h-full hover:shadow-lg hover:shadow-accent/30 transition-all duration-300">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-foreground/70">Water Quality Index</h3>
                <Droplets className="h-5 w-5 text-accent" />
              </div>
              <div className="stat-counter text-4xl mb-2">
                <AnimatedCounter target={metrics.waterQuality} />%
              </div>
              <div className="text-xs text-foreground/50">Global Average</div>
              <div className="mt-4 w-full bg-card rounded-full h-2">
                <div
                  className="bg-accent h-2 rounded-full transition-all duration-1000"
                  style={{ width: `${metrics.waterQuality}%` }}
                />
              </div>
            </Card>
          </motion.div>

          {/* Coral Health */}
          <motion.div variants={itemVariants}>
            <Card className="glass p-6 h-full hover:shadow-lg hover:shadow-accent/30 transition-all duration-300">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-foreground/70">Coral Health</h3>
                <Heart className="h-5 w-5 text-secondary" />
              </div>
              <div className="stat-counter text-4xl mb-2">
                <AnimatedCounter target={metrics.coralHealth} />%
              </div>
              <div className="text-xs text-foreground/50">Protected Reefs</div>
              <div className="mt-4 w-full bg-card rounded-full h-2">
                <div
                  className="bg-secondary h-2 rounded-full transition-all duration-1000"
                  style={{ width: `${metrics.coralHealth}%` }}
                />
              </div>
            </Card>
          </motion.div>

          {/* Plastic Density */}
          <motion.div variants={itemVariants}>
            <Card className="glass p-6 h-full hover:shadow-lg hover:shadow-accent/30 transition-all duration-300">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-foreground/70">Plastic Density</h3>
                <Trash2 className="h-5 w-5 text-red-400" />
              </div>
              <div className="stat-counter text-4xl mb-2">
                <AnimatedCounter target={metrics.plasticDensity} />
              </div>
              <div className="text-xs text-foreground/50">kg/km²</div>
              <div className="mt-4 text-xs text-red-400/70">⚠ Above Safe Levels</div>
            </Card>
          </motion.div>

          {/* Marine Species */}
          <motion.div variants={itemVariants}>
            <Card className="glass p-6 h-full hover:shadow-lg hover:shadow-accent/30 transition-all duration-300">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-foreground/70">Marine Species</h3>
                <Fish className="h-5 w-5 text-accent" />
              </div>
              <div className="stat-counter text-4xl mb-2">
                <AnimatedCounter target={metrics.marineSpecies} />
              </div>
              <div className="text-xs text-foreground/50">Detected Species</div>
              <div className="mt-4 text-xs text-accent/70">↑ 12% vs Last Month</div>
            </Card>
          </motion.div>

          {/* Risk Index */}
          <motion.div variants={itemVariants}>
            <Card className="glass p-6 h-full hover:shadow-lg hover:shadow-accent/30 transition-all duration-300">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-foreground/70">Risk Index</h3>
                <AlertTriangle className="h-5 w-5 text-yellow-400" />
              </div>
              <div className="stat-counter text-4xl mb-2">
                <AnimatedCounter target={metrics.riskIndex} />
              </div>
              <div className="text-xs text-foreground/50">Global Threat Level</div>
              <div className="mt-4 w-full bg-card rounded-full h-2">
                <div
                  className="bg-yellow-500 h-2 rounded-full transition-all duration-1000"
                  style={{ width: `${metrics.riskIndex}%` }}
                />
              </div>
            </Card>
          </motion.div>
        </motion.div>

        {/* Detailed Metrics Section */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid lg:grid-cols-2 gap-6"
        >
          {/* Ocean Health Zones */}
          <motion.div variants={itemVariants}>
            <Card className="glass p-8">
              <h2 className="text-2xl font-bold text-accent mb-6">Ocean Health Zones</h2>
              <div className="space-y-4">
                {[
                  { zone: 'Atlantic Ocean', health: 72, status: 'Moderate' },
                  { zone: 'Pacific Ocean', health: 68, status: 'Moderate' },
                  { zone: 'Indian Ocean', health: 65, status: 'Critical' },
                  { zone: 'Arctic Region', health: 55, status: 'Critical' }
                ].map((item, idx) => (
                  <div key={idx} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-foreground/80">{item.zone}</span>
                      <span className={`text-xs px-2 py-1 rounded ${
                        item.health > 70 ? 'badge-info' :
                        item.health > 60 ? 'badge-warning' :
                        'badge-critical'
                      }`}>
                        {item.status}
                      </span>
                    </div>
                    <div className="w-full bg-card rounded-full h-2">
                      <div
                        className={`h-2 rounded-full transition-all duration-1000 ${
                          item.health > 70 ? 'bg-accent' :
                          item.health > 60 ? 'bg-yellow-500' :
                          'bg-red-500'
                        }`}
                        style={{ width: `${item.health}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>

          {/* Recent Alerts */}
          <motion.div variants={itemVariants}>
            <Card className="glass p-8">
              <h2 className="text-2xl font-bold text-accent mb-6">Recent Alerts</h2>
              <div className="space-y-4">
                {[
                  { type: 'Pollution Spike', location: 'North Atlantic', time: '2 hours ago', severity: 'critical' },
                  { type: 'Illegal Fishing', location: 'South Pacific', time: '4 hours ago', severity: 'warning' },
                  { type: 'Coral Bleaching', location: 'Great Barrier Reef', time: '6 hours ago', severity: 'warning' },
                  { type: 'Oil Spill Detection', location: 'Gulf of Mexico', time: '8 hours ago', severity: 'critical' }
                ].map((alert, idx) => (
                  <div key={idx} className={`p-4 rounded-lg border ${
                    alert.severity === 'critical' ? 'badge-critical' : 'badge-warning'
                  }`}>
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-semibold text-foreground">{alert.type}</p>
                        <p className="text-sm text-foreground/70">{alert.location}</p>
                      </div>
                      <span className="text-xs text-foreground/50">{alert.time}</span>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
