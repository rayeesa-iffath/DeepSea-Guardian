import { useCallback, useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';

export interface CarouselItem {
  id: number;
  name: string;
  image: string;
  subtitle?: string;
}

interface SpeciesCarouselProps {
  items: CarouselItem[];
  onSelect?: (id: number) => void;
  autoPlayMs?: number;
}

export default function SpeciesCarousel({ items, onSelect, autoPlayMs = 3200 }: SpeciesCarouselProps) {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const count = items.length;

  const goTo = useCallback(
    (i: number) => {
      if (count === 0) return;
      setIndex(((i % count) + count) % count);
    },
    [count]
  );

  const next = useCallback(() => goTo(index + 1), [goTo, index]);
  const prev = useCallback(() => goTo(index - 1), [goTo, index]);

  useEffect(() => {
    if (paused || count === 0) return;
    timerRef.current = setInterval(() => {
      setIndex((i) => (i + 1) % count);
    }, autoPlayMs);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [paused, count, autoPlayMs]);

  if (count === 0) {
    return (
      <div className="flex h-full w-full items-center justify-center text-foreground/50">
        No species to display yet.
      </div>
    );
  }

  // Build an offset list so we always render a fixed window around the active item,
  // which keeps the 3D positions stable regardless of array length.
  const visibleRange = [-2, -1, 0, 1, 2];

  return (
    <div
      className="relative h-full w-full select-none"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      style={{ perspective: 1200 }}
    >
      <div className="relative flex h-full w-full items-center justify-center overflow-hidden">
        {visibleRange.map((offset) => {
          const itemIndex = ((index + offset) % count + count) % count;
          const item = items[itemIndex];
          const abs = Math.abs(offset);
          const isCenter = offset === 0;

          return (
            <motion.div
              key={`${item.id}-${offset}`}
              className="absolute cursor-pointer"
              style={{ zIndex: 10 - abs }}
              initial={false}
              animate={{
                x: offset * 150,
                scale: isCenter ? 1 : 1 - abs * 0.22,
                opacity: abs > 2 ? 0 : 1 - abs * 0.3,
                rotateY: offset * -18,
                filter: isCenter ? 'brightness(1)' : 'brightness(0.6)',
              }}
              transition={{ type: 'spring', stiffness: 220, damping: 26 }}
              onClick={() => {
                if (isCenter) {
                  onSelect?.(item.id);
                } else {
                  goTo(itemIndex);
                }
              }}
            >
              <div
                className={`overflow-hidden rounded-2xl border shadow-xl ${
                  isCenter ? 'border-accent/60 shadow-accent/30' : 'border-border shadow-black/30'
                }`}
                style={{ width: isCenter ? 220 : 160, height: isCenter ? 220 : 160 }}
              >
                <img src={item.image} alt={item.name} className="h-full w-full object-cover" draggable={false} />
              </div>
              <AnimatePresence>
                {isCenter && (
                  <motion.p
                    initial={{ opacity: 0, y: -6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="mt-3 text-center text-sm font-semibold text-accent"
                  >
                    {item.name}
                  </motion.p>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })}
      </div>

      <button
        aria-label="Previous species"
        onClick={prev}
        className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-card/70 p-2 text-foreground/80 backdrop-blur-sm transition-colors hover:bg-card hover:text-accent"
      >
        <ChevronLeft className="h-5 w-5" />
      </button>
      <button
        aria-label="Next species"
        onClick={next}
        className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-card/70 p-2 text-foreground/80 backdrop-blur-sm transition-colors hover:bg-card hover:text-accent"
      >
        <ChevronRight className="h-5 w-5" />
      </button>

      <div className="absolute bottom-2 left-1/2 flex -translate-x-1/2 gap-2">
        {items.map((item, i) => (
          <button
            key={item.id}
            aria-label={`Go to ${item.name}`}
            onClick={() => goTo(i)}
            className={`h-1.5 rounded-full transition-all ${
              i === index ? 'w-6 bg-accent' : 'w-1.5 bg-foreground/30'
            }`}
          />
        ))}
      </div>
    </div>
  );
}
