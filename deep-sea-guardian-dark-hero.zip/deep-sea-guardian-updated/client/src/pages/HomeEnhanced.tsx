import { useEffect, useState } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Link } from 'wouter';
import Ferrofluid from '@/components/Ferrofluid';
import PixelBlast from '@/components/PixelBlast';
import { Button } from '@/components/ui/button';
import { Waves, Zap, Map, Users, AlertCircle, TrendingUp } from 'lucide-react';

const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.8 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.3
    }
  }
};

const scaleIn = {
  hidden: { opacity: 0, scale: 0.8 },
  visible: { opacity: 1, scale: 1, transition: { duration: 0.6 } }
};

export default function HomeEnhanced() {
  const { scrollY } = useScroll();
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  const heroY = useTransform(scrollY, [0, 300], [0, 100]);
  const heroOpacity = useTransform(scrollY, [0, 300], [1, 0.5]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const features = [
    {
      icon: Zap,
      title: 'Real-Time Dashboard',
      description: 'Live metrics for water quality, coral health, plastic density, and marine species',
      href: '/dashboard',
      color: 'from-emerald-500 to-teal-500'
    },
    {
      icon: Map,
      title: 'Interactive World Map',
      description: 'Clickable hotspots for pollution zones, illegal fishing, and protected areas',
      href: '/map',
      color: 'from-teal-500 to-emerald-400'
    },
    {
      icon: Users,
      title: 'Species Recognition',
      description: 'AI-powered marine species identification with detailed biodiversity insights',
      href: '/species',
      color: 'from-green-500 to-emerald-400'
    },
    {
      icon: AlertCircle,
      title: 'Alert Center',
      description: 'Real-time conservation alerts with severity levels and timestamps',
      href: '/alerts',
      color: 'from-red-500 to-orange-500'
    },
    {
      icon: TrendingUp,
      title: 'Risk Prediction',
      description: 'Forecasted environmental damage trends and climate impact analysis',
      href: '/analytics',
      color: 'from-orange-500 to-red-500'
    },
    {
      icon: Waves,
      title: 'Ocean Digital Twin',
      description: 'Advanced visualization of ocean health and predictive modeling',
      href: '/dashboard',
      color: 'from-amber-400 to-emerald-500'
    }
  ];

  return (
    <div className="min-h-screen text-foreground overflow-hidden">
      <div className="fixed inset-0 pointer-events-none" style={{ zIndex: 1 }}>
        <PixelBlast
          variant="square"
          pixelSize={5}
          color="#0d3b36"
          patternScale={2.5}
          patternDensity={1}
          pixelSizeJitter={0.4}
          enableRipples
          rippleSpeed={0.35}
          rippleThickness={0.12}
          rippleIntensityScale={1.3}
          liquid
          liquidStrength={0.1}
          liquidRadius={1.1}
          liquidWobbleSpeed={4.5}
          speed={0.45}
          edgeFade={0.3}
          transparent
        />
      </div>

      {/* Hero Section */}
      <section className="relative h-screen overflow-hidden flex items-center justify-center bg-[#020a09]">
        <div className="absolute inset-0 z-0">
          <Ferrofluid
            colors={['#041a17', '#0a2e29', '#0f3d36']}
            speed={0.4}
            scale={1.2}
            turbulence={0.9}
            fluidity={0.15}
            rimWidth={0.25}
            sharpness={2}
            shimmer={0.6}
            glow={0.4}
            flowDirection="down"
            opacity={0.85}
            mouseInteraction={true}
            mouseStrength={0.8}
            mouseRadius={0.4}
          />
        </div>
        {/* Deep-sea vignette so the fluid reads as dark water, not a bright wash */}
        <div
          className="absolute inset-0 z-[1] pointer-events-none"
          style={{
            background:
              'radial-gradient(ellipse at 50% 40%, rgba(2,10,9,0.15) 0%, rgba(2,10,9,0.55) 55%, rgba(2,10,9,0.92) 100%)'
          }}
        />
        <div
          className="absolute inset-0 z-[1] pointer-events-none"
          style={{ background: 'linear-gradient(180deg, rgba(2,10,9,0.75) 0%, rgba(2,10,9,0) 25%, rgba(2,10,9,0) 70%, rgba(2,10,9,0.95) 100%)' }}
        />

        {/* Hero Content */}
        <motion.div
          style={{ y: heroY, opacity: heroOpacity }}
          className="relative z-10 text-center max-w-5xl mx-auto px-4"
        >
          <motion.div
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
          >
            <motion.div
              variants={fadeInUp}
              className="mb-6 inline-block"
            >
              <div className="px-6 py-3 rounded-full bg-accent/20 border border-accent/50 backdrop-blur-sm">
                <p className="text-accent font-semibold text-sm">Ocean Conservation Intelligence</p>
              </div>
            </motion.div>

            <motion.h1
              variants={fadeInUp}
              className="text-6xl md:text-8xl font-bold mb-6 text-accent drop-shadow-2xl"
            >
              DeepSea Guardian
            </motion.h1>

            <motion.p
              variants={fadeInUp}
              className="text-2xl md:text-3xl mb-8 text-foreground/90 drop-shadow-lg font-light"
            >
              AI-Powered Ocean Intelligence Platform
            </motion.p>

            <motion.p
              variants={fadeInUp}
              className="text-lg md:text-xl mb-12 text-foreground/80 max-w-3xl mx-auto drop-shadow-md"
            >
              Real-time monitoring of ocean pollution, biodiversity, and environmental threats.
              Empowering governments, NGOs, and researchers with actionable ocean conservation intelligence.
            </motion.p>

            <motion.div
              variants={fadeInUp}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Link href="/dashboard">
                <motion.div
                  whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(0, 217, 255, 0.6)' }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button
                    size="lg"
                    className="bg-accent text-accent-foreground hover:bg-accent/90 neon-glow text-lg px-8 py-6"
                  >
                    <Zap className="mr-3 h-6 w-6" />
                    Launch Dashboard
                  </Button>
                </motion.div>
              </Link>
              <Link href="/map">
                <motion.div
                  whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(0, 217, 255, 0.4)' }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-2 border-accent text-accent hover:bg-accent/10 text-lg px-8 py-6"
                  >
                    <Map className="mr-3 h-6 w-6" />
                    Explore Map
                  </Button>
                </motion.div>
              </Link>
            </motion.div>
          </motion.div>
        </motion.div>

        {/* Animated Scroll Indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
          animate={{ y: [0, 15, 0] }}
          transition={{ duration: 2.5, repeat: Infinity }}
        >
          <div className="flex flex-col items-center gap-2">
            <p className="text-accent text-sm font-semibold">Scroll to explore</p>
            <Waves className="h-6 w-6 text-accent animate-pulse" />
          </div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="py-24 px-4 bg-gradient-to-b from-background via-card/20 to-background relative">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-20"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-accent via-secondary to-accent bg-clip-text text-transparent">
              Platform Features
            </h2>
            <p className="text-foreground/70 text-xl max-w-2xl mx-auto">
              Comprehensive ocean monitoring and conservation intelligence powered by advanced AI
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -10, boxShadow: '0 20px 40px rgba(0, 217, 255, 0.2)' }}
              >
                <Link href={feature.href}>
                  <div className="glass rounded-2xl p-8 h-full cursor-pointer group hover:border-accent/50 transition-all duration-300">
                    <div className={`bg-gradient-to-br ${feature.color} p-4 rounded-xl w-fit mb-6 group-hover:scale-110 transition-transform`}>
                      <feature.icon className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold mb-3 text-foreground group-hover:text-accent transition-colors">
                      {feature.title}
                    </h3>
                    <p className="text-foreground/70 leading-relaxed">
                      {feature.description}
                    </p>
                    <div className="mt-6 flex items-center text-accent opacity-0 group-hover:opacity-100 transition-opacity">
                      <span className="text-sm font-semibold">Explore →</span>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-4 bg-card/50 border-t border-border">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="grid md:grid-cols-4 gap-8"
          >
            {[
              { label: 'Ocean Zones', value: '12+', icon: '🌊' },
              { label: 'Species Tracked', value: '1,247', icon: '🐠' },
              { label: 'Active Alerts', value: '6', icon: '⚠️' },
              { label: 'Risk Index', value: '72%', icon: '📊' }
            ].map((stat, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <div className="text-4xl mb-3">{stat.icon}</div>
                <div className="stat-counter text-4xl font-bold text-accent mb-2">
                  {stat.value}
                </div>
                <p className="text-foreground/70">{stat.label}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-4 bg-gradient-to-b from-background to-card/30">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto text-center"
        >
          <h2 className="text-5xl font-bold mb-6 text-accent">
            Join the Ocean Conservation Mission
          </h2>
          <p className="text-lg text-foreground/70 mb-12">
            Explore real-time ocean intelligence and contribute to global marine conservation efforts.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/dashboard">
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button className="bg-accent text-accent-foreground hover:bg-accent/90 neon-glow text-lg px-8 py-6">
                  Start Monitoring
                </Button>
              </motion.div>
            </Link>
            <Link href="/map">
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button variant="outline" className="border-2 border-accent text-accent hover:bg-accent/10 text-lg px-8 py-6">
                  View Global Map
                </Button>
              </motion.div>
            </Link>
          </div>
        </motion.div>
      </section>
    </div>
  );
}
