export default function Navbar() {
  return (
    <header className="h-16 w-full bg-slate-900 text-white flex items-center justify-between px-6 shadow">
      <div className="flex items-center gap-2">
        <span className="w-3 h-3 rounded-full bg-cyan-400 shadow-[0_0_8px_2px_rgba(34,211,238,0.6)]"></span>
        <h1 className="font-semibold tracking-wide text-lg">DeepSea Guardian</h1>
      </div>
      <nav className="text-sm text-slate-300">
        Ocean Intelligence Platform
      </nav>
    </header>
  );
}
