import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { X, Zap, Droplet, Ruler } from 'lucide-react';
import SpeciesCarousel from '@/components/SpeciesCarousel';

const speciesData = [
  {
    id: 1,
    name: 'Blue Whale',
    image: 'https://images.unsplash.com/photo-1520646924857-261be3037bc7?w=400&h=400&fit=crop',
    confidence: 98,
    depth: '0-200m',
    status: 'Endangered',
    description: 'The largest animal ever known to exist, the blue whale can grow up to 100 feet long.'
  },
  {
    id: 2,
    name: 'Manta Ray',
    image: 'https://images.unsplash.com/photo-1692810122794-f321b05c74ad?w=400&h=400&fit=crop',
    confidence: 95,
    depth: '0-100m',
    status: 'Vulnerable',
    description: 'Graceful ocean giants with wingspans up to 23 feet, known for their intelligence.'
  },
  {
    id: 3,
    name: 'Sea Turtle',
    image: 'https://images.unsplash.com/photo-1471079502516-250c19af6928?w=400&h=400&fit=crop',
    confidence: 92,
    depth: '0-300m',
    status: 'Vulnerable',
    description: 'Ancient mariners that have existed for over 100 million years.'
  },
  {
    id: 4,
    name: 'Octopus',
    image: 'https://images.unsplash.com/photo-1561479639-747efc0d0bf2?w=400&h=400&fit=crop',
    confidence: 89,
    depth: '0-1000m',
    status: 'Stable',
    description: 'Highly intelligent invertebrates with remarkable problem-solving abilities.'
  },
  {
    id: 5,
    name: 'Seahorse',
    image: 'https://images.unsplash.com/photo-1637308116159-078c84bf5317?w=400&h=400&fit=crop',
    confidence: 87,
    depth: '0-100m',
    status: 'Vulnerable',
    description: 'Unique creatures where males carry and give birth to young.'
  },
  {
    id: 6,
    name: 'Jellyfish',
    image: 'https://images.unsplash.com/photo-1726650683801-ea583e91db16?w=400&h=400&fit=crop',
    confidence: 94,
    depth: '0-2000m',
    status: 'Stable',
    description: 'Ancient creatures that existed before dinosaurs, composed of 95% water.'
  }
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1, delayChildren: 0.2 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

export default function SpeciesEnhanced() {
  const [selectedSpecies, setSelectedSpecies] = useState<typeof speciesData[0] | null>(null);
  const [hoveredId, setHoveredId] = useState<number | null>(null);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Endangered':
        return 'bg-red-500/20 text-red-400 border-red-500/50';
      case 'Vulnerable':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50';
      default:
        return 'bg-green-500/20 text-green-400 border-green-500/50';
    }
  };

  return (
    <div className="min-h-screen pt-32 pb-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12 text-center"
        >
          <h1 className="text-5xl md:text-6xl font-bold text-accent mb-2">
            Species Recognition
          </h1>
          <p className="text-foreground/70 text-lg">
            AI-powered marine biodiversity identification and tracking
          </p>
        </motion.div>

        {/* Circular Gallery */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="mb-16"
        >
          <Card className="glass p-8">
            <h2 className="text-2xl font-bold text-accent mb-6">Interactive Species Gallery</h2>
            <p className="text-foreground/60 text-sm mb-4 -mt-4">
              Auto-rotating showcase — click the centered species for full details, or use the arrows and dots to browse.
            </p>
            <div className="h-96">
              <SpeciesCarousel
                items={speciesData.map((s) => ({ id: s.id, name: s.name, image: s.image }))}
                onSelect={(id) => setSelectedSpecies(speciesData.find((s) => s.id === id) ?? null)}
              />
            </div>
          </Card>
        </motion.div>

        {/* Species Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12"
        >
          {speciesData.map((species, idx) => (
            <motion.div
              key={species.id}
              variants={itemVariants}
              onHoverStart={() => setHoveredId(species.id)}
              onHoverEnd={() => setHoveredId(null)}
              onClick={() => setSelectedSpecies(species)}
              className="cursor-pointer group"
            >
              <Card className="glass p-0 overflow-hidden h-full hover:shadow-lg hover:shadow-accent/30 transition-all duration-300">
                {/* Image Container */}
                <div className="relative h-48 overflow-hidden bg-card/50">
                  <motion.img
                    src={species.image}
                    alt={species.name}
                    className="w-full h-full object-cover"
                    animate={{ scale: hoveredId === species.id ? 1.1 : 1 }}
                    transition={{ duration: 0.3 }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                  {/* Confidence Badge */}
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="absolute top-3 right-3"
                  >
                    <div className="bg-accent/20 border border-accent/50 rounded-lg px-3 py-1 backdrop-blur-sm">
                      <p className="text-xs font-semibold text-accent">{species.confidence}% Match</p>
                    </div>
                  </motion.div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-accent transition-colors">
                    {species.name}
                  </h3>

                  <div className="space-y-3 mb-4">
                    <div className="flex items-center gap-2 text-sm text-foreground/70">
                      <Droplet className="h-4 w-4 text-accent" />
                      <span>Depth: {species.depth}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-foreground/70">
                      <Zap className="h-4 w-4 text-accent" />
                      <span>Status: {species.status}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className={`text-xs px-3 py-1 rounded-full border ${getStatusColor(species.status)}`}>
                      {species.status.toUpperCase()}
                    </span>
                    <motion.div
                      animate={{ x: hoveredId === species.id ? 5 : 0 }}
                      className="text-accent"
                    >
                      →
                    </motion.div>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Selected Species Modal */}
        <AnimatePresence>
          {selectedSpecies && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedSpecies(null)}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-card border border-border rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl"
              >
                <div className="grid md:grid-cols-2 gap-8 p-8">
                  {/* Image */}
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1 }}
                    className="relative h-64 md:h-96 rounded-xl overflow-hidden"
                  >
                    <img
                      src={selectedSpecies.image}
                      alt={selectedSpecies.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background/50 to-transparent" />
                  </motion.div>

                  {/* Details */}
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1 }}
                    className="flex flex-col justify-between"
                  >
                    <div>
                      <h2 className="text-4xl font-bold text-accent mb-4">
                        {selectedSpecies.name}
                      </h2>

                      <div className="space-y-4 mb-6">
                        <div>
                          <p className="text-foreground/70 text-sm mb-1">AI Identification Confidence</p>
                          <div className="flex items-center gap-3">
                            <div className="flex-1 h-2 bg-card/50 rounded-full overflow-hidden">
                              <motion.div
                                initial={{ width: 0 }}
                                animate={{ width: `${selectedSpecies.confidence}%` }}
                                transition={{ duration: 0.8, delay: 0.2 }}
                                className="h-full bg-gradient-to-r from-accent to-secondary"
                              />
                            </div>
                            <span className="text-accent font-semibold">{selectedSpecies.confidence}%</span>
                          </div>
                        </div>

                        <div>
                          <p className="text-foreground/70 text-sm mb-2">Conservation Status</p>
                          <span className={`inline-block text-xs px-4 py-2 rounded-full border ${getStatusColor(selectedSpecies.status)}`}>
                            {selectedSpecies.status.toUpperCase()}
                          </span>
                        </div>

                        <div>
                          <p className="text-foreground/70 text-sm mb-2">Habitat Depth</p>
                          <p className="text-foreground font-semibold">{selectedSpecies.depth}</p>
                        </div>
                      </div>

                      <div>
                        <p className="text-foreground/70 text-sm mb-2">Description</p>
                        <p className="text-foreground leading-relaxed">
                          {selectedSpecies.description}
                        </p>
                      </div>
                    </div>

                    <div className="mt-6 pt-6 border-t border-border">
                      <p className="text-xs text-foreground/50 mb-3">Powered by Advanced AI Recognition</p>
                      <button
                        onClick={() => setSelectedSpecies(null)}
                        className="w-full py-2 px-4 rounded-lg bg-accent/20 border border-accent/50 text-accent hover:bg-accent/30 transition-colors font-semibold"
                      >
                        Close Details
                      </button>
                    </div>
                  </motion.div>
                </div>

                {/* Close Button */}
                <button
                  onClick={() => setSelectedSpecies(null)}
                  className="absolute top-4 right-4 p-2 rounded-lg bg-card/50 hover:bg-card/80 transition-colors"
                >
                  <X className="h-6 w-6 text-foreground" />
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
