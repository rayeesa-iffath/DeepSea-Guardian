import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { AlertTriangle, MapPin, Zap } from 'lucide-react';

// Fix Leaflet default icon issue
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png'
});

// Mock hotspot data
const hotspotsData = [
  {
    id: 1,
    name: 'North Atlantic Pollution Zone',
    lat: 45.2,
    lng: -52.3,
    type: 'pollution',
    severity: 'critical',
    description: 'Hazardous chemical discharge detected'
  },
  {
    id: 2,
    name: 'South Pacific Illegal Fishing',
    lat: -18.5,
    lng: 165.2,
    type: 'fishing',
    severity: 'critical',
    description: 'Unauthorized fishing vessel detected'
  },
  {
    id: 3,
    name: 'Great Barrier Reef Bleaching',
    lat: -16.2,
    lng: 145.8,
    type: 'coral',
    severity: 'warning',
    description: 'Elevated water temperature causing coral stress'
  },
  {
    id: 4,
    name: 'Gulf of Mexico Oil Spill',
    lat: 27.5,
    lng: -89.2,
    type: 'pollution',
    severity: 'critical',
    description: 'Significant oil slick detected'
  },
  {
    id: 5,
    name: 'Mediterranean Protected Zone',
    lat: 36.5,
    lng: 15.2,
    type: 'protected',
    severity: 'info',
    description: 'Marine protected area - biodiversity hotspot'
  },
  {
    id: 6,
    name: 'Baltic Sea Mortality Event',
    lat: 55.3,
    lng: 18.5,
    type: 'mortality',
    severity: 'warning',
    description: 'Unusual marine mammal mortality detected'
  }
];

export default function OceanMap() {
  const mapRef = useRef<L.Map | null>(null);
  const [selectedHotspot, setSelectedHotspot] = useState<typeof hotspotsData[0] | null>(null);

  useEffect(() => {
    // Initialize map
    const map = L.map('map').setView([20, 0], 2);

    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '© OpenStreetMap contributors © CARTO',
      maxZoom: 19
    }).addTo(map);

    // Add hotspots
    hotspotsData.forEach(hotspot => {
      let iconColor = '#00d9ff';
      let iconSymbol = '⚠';

      if (hotspot.type === 'pollution') {
        iconColor = '#ff4444';
        iconSymbol = '☠';
      } else if (hotspot.type === 'fishing') {
        iconColor = '#ff6b6b';
        iconSymbol = '🎣';
      } else if (hotspot.type === 'coral') {
        iconColor = '#ffd700';
        iconSymbol = '🪸';
      } else if (hotspot.type === 'protected') {
        iconColor = '#ffd166';
        iconSymbol = '✓';
      }

      const customIcon = L.divIcon({
        html: `
          <div style="
            background-color: ${iconColor};
            color: white;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            border: 3px solid rgba(255,255,255,0.3);
            box-shadow: 0 0 10px ${iconColor};
            cursor: pointer;
          ">
            ${iconSymbol}
          </div>
        `,
        className: 'custom-icon',
        iconSize: [40, 40],
        iconAnchor: [20, 20],
        popupAnchor: [0, -20]
      });

      const marker = L.marker([hotspot.lat, hotspot.lng], { icon: customIcon }).addTo(map);

      marker.on('click', () => {
        setSelectedHotspot(hotspot);
      });

      marker.bindPopup(`
        <div style="color: #061a17; font-family: system-ui;">
          <strong>${hotspot.name}</strong><br/>
          <small>${hotspot.description}</small>
        </div>
      `);
    });

    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  const getHotspotIcon = (type: string) => {
    switch (type) {
      case 'pollution':
        return <AlertTriangle className="h-5 w-5" />;
      case 'fishing':
        return <Zap className="h-5 w-5" />;
      case 'protected':
        return <MapPin className="h-5 w-5" />;
      default:
        return <AlertTriangle className="h-5 w-5" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'badge-critical';
      case 'warning':
        return 'badge-warning';
      default:
        return 'badge-info';
    }
  };

  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-accent mb-2">
            Interactive World Ocean Map
          </h1>
          <p className="text-foreground/70 text-lg">
            Real-time visualization of ocean hotspots and conservation zones
          </p>
        </motion.div>

        {/* Map and Details Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Map */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-2"
          >
            <Card className="glass p-0 overflow-hidden h-96 lg:h-full min-h-96">
              <div id="map" className="w-full h-full" />
            </Card>
          </motion.div>

          {/* Hotspots List */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-1"
          >
            <Card className="glass p-6 h-full overflow-y-auto max-h-96 lg:max-h-full">
              <h2 className="text-xl font-bold text-accent mb-4">Active Hotspots</h2>
              <div className="space-y-3">
                {hotspotsData.map((hotspot) => (
                  <motion.div
                    key={hotspot.id}
                    onClick={() => setSelectedHotspot(hotspot)}
                    className={`p-3 rounded-lg cursor-pointer transition-all duration-300 ${
                      selectedHotspot?.id === hotspot.id
                        ? 'bg-accent/20 border border-accent'
                        : 'bg-card/50 border border-border hover:bg-card/80'
                    }`}
                    whileHover={{ scale: 1.02 }}
                  >
                    <div className="flex items-start gap-2">
                      <div className="text-accent mt-1">
                        {getHotspotIcon(hotspot.type)}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-semibold text-foreground">
                          {hotspot.name}
                        </p>
                        <p className="text-xs text-foreground/60 mt-1">
                          {hotspot.lat.toFixed(1)}°, {hotspot.lng.toFixed(1)}°
                        </p>
                        <div className="mt-2">
                          <span className={`text-xs px-2 py-1 rounded ${getSeverityColor(hotspot.severity)}`}>
                            {hotspot.severity.toUpperCase()}
                          </span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </Card>
          </motion.div>
        </div>

        {/* Selected Hotspot Details */}
        {selectedHotspot && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="mt-6"
          >
            <Card className="glass p-8">
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-2xl font-bold text-accent mb-4">
                    {selectedHotspot.name}
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <p className="text-foreground/70 text-sm mb-1">Type</p>
                      <p className="text-foreground font-semibold capitalize">
                        {selectedHotspot.type.replace('_', ' ')}
                      </p>
                    </div>
                    <div>
                      <p className="text-foreground/70 text-sm mb-1">Coordinates</p>
                      <p className="text-foreground font-semibold">
                        {selectedHotspot.lat.toFixed(2)}°, {selectedHotspot.lng.toFixed(2)}°
                      </p>
                    </div>
                    <div>
                      <p className="text-foreground/70 text-sm mb-1">Severity</p>
                      <span className={`inline-block text-xs px-3 py-1 rounded ${getSeverityColor(selectedHotspot.severity)}`}>
                        {selectedHotspot.severity.toUpperCase()}
                      </span>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-accent mb-3">Description</h4>
                  <p className="text-foreground/70 leading-relaxed mb-6">
                    {selectedHotspot.description}
                  </p>
                  <div className="space-y-2">
                    <p className="text-sm text-foreground/70">
                      <span className="text-accent">Status:</span> Active Monitoring
                    </p>
                    <p className="text-sm text-foreground/70">
                      <span className="text-accent">Last Updated:</span> 5 minutes ago
                    </p>
                    <p className="text-sm text-foreground/70">
                      <span className="text-accent">Affected Area:</span> ~150 km²
                    </p>
                  </div>
                </div>
              </div>
            </Card>
          </motion.div>
        )}

        {/* Legend */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mt-8"
        >
          <Card className="glass p-6">
            <h3 className="text-lg font-bold text-accent mb-4">Map Legend</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-red-500 shadow-lg shadow-red-500/50" />
                <span className="text-sm text-foreground/70">Pollution Zone</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-red-600 shadow-lg shadow-red-600/50" />
                <span className="text-sm text-foreground/70">Illegal Fishing</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-yellow-500 shadow-lg shadow-yellow-500/50" />
                <span className="text-sm text-foreground/70">Coral Bleaching</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-400 shadow-lg shadow-emerald-400/50" />
                <span className="text-sm text-foreground/70">Protected Zone</span>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
