import drones from "../data/drones.json";

export default function Fleet() {
  return (
    <div>
      <h2 className="text-xl font-semibold text-slate-800 mb-4">Drone Fleet</h2>
      <ul className="space-y-2">
        {drones.map((d) => (
          <li
            key={d.id}
            className="bg-white border border-slate-200 rounded-lg px-4 py-3 text-sm flex justify-between"
          >
            <span className="font-medium">{d.id}</span>
            <span className="text-slate-500">{d.type} · {d.zone}</span>
            <span className="text-slate-500">{d.status}</span>
            <span className="text-slate-500">{d.battery}%</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
