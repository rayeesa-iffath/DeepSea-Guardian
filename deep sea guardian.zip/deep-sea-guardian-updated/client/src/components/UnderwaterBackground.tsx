import { useMemo } from 'react';
import './UnderwaterBackground.css';

interface FishSpec {
  id: number;
  top: string;
  duration: number;
  delay: number;
  scale: number;
  opacity: number;
  flipped: boolean;
  hue: string;
}

interface BubbleSpec {
  id: number;
  left: string;
  size: number;
  duration: number;
  delay: number;
}

interface WeedSpec {
  id: number;
  left: string;
  height: number;
  duration: number;
  delay: number;
}

function Fish({ hue }: { hue: string }) {
  return (
    <svg
      viewBox="0 0 100 50"
      className="uw-fish-svg"
      style={{ ['--fish-color' as string]: hue }}
    >
      <ellipse cx="42" cy="25" rx="30" ry="14" className="uw-fish-body" />
      <path d="M12 25 L-6 10 L-6 40 Z" className="uw-fish-tail" />
      <path d="M40 12 L52 -2 L58 14 Z" className="uw-fish-fin" />
      <circle cx="62" cy="21" r="3" className="uw-fish-eye" />
    </svg>
  );
}

export default function UnderwaterBackground() {
  const fishes = useMemo<FishSpec[]>(
    () => [
      { id: 1, top: '12%', duration: 26, delay: 0, scale: 0.9, opacity: 0.5, flipped: false, hue: 'var(--accent)' },
      { id: 2, top: '24%', duration: 34, delay: 6, scale: 0.55, opacity: 0.35, flipped: true, hue: 'var(--secondary)' },
      { id: 3, top: '38%', duration: 22, delay: 3, scale: 1.15, opacity: 0.6, flipped: false, hue: 'var(--chart-3)' },
      { id: 4, top: '52%', duration: 40, delay: 10, scale: 0.7, opacity: 0.4, flipped: true, hue: 'var(--accent)' },
      { id: 5, top: '65%', duration: 30, delay: 14, scale: 0.85, opacity: 0.45, flipped: false, hue: 'var(--secondary)' },
      { id: 6, top: '76%', duration: 46, delay: 4, scale: 0.5, opacity: 0.3, flipped: true, hue: 'var(--chart-3)' },
      { id: 7, top: '18%', duration: 50, delay: 20, scale: 0.4, opacity: 0.25, flipped: false, hue: 'var(--accent)' },
      { id: 8, top: '88%', duration: 36, delay: 8, scale: 0.65, opacity: 0.35, flipped: true, hue: 'var(--secondary)' },
    ],
    []
  );

  const bubbles = useMemo<BubbleSpec[]>(
    () =>
      Array.from({ length: 18 }, (_, i) => ({
        id: i,
        left: `${(i * 137.5) % 100}%`,
        size: 4 + ((i * 7) % 14),
        duration: 8 + ((i * 5) % 12),
        delay: (i * 1.3) % 10,
      })),
    []
  );

  const weeds = useMemo<WeedSpec[]>(
    () =>
      Array.from({ length: 9 }, (_, i) => ({
        id: i,
        left: `${(i / 9) * 100 + 3}%`,
        height: 60 + ((i * 23) % 90),
        duration: 5 + (i % 4),
        delay: (i * 0.6) % 3,
      })),
    []
  );

  return (
    <div className="uw-root" aria-hidden="true">
      <div className="uw-gradient" />
      <div className="uw-rays" />

      {bubbles.map((b) => (
        <span
          key={b.id}
          className="uw-bubble"
          style={{
            left: b.left,
            width: b.size,
            height: b.size,
            animationDuration: `${b.duration}s`,
            animationDelay: `${b.delay}s`,
          }}
        />
      ))}

      {fishes.map((f) => (
        <div
          key={f.id}
          className="uw-fish-track"
          style={{
            top: f.top,
            animationDuration: `${f.duration}s`,
            animationDelay: `${f.delay}s`,
            opacity: f.opacity,
          }}
        >
          <div
            className="uw-fish-bob"
            style={{
              transform: `scale(${f.scale}) ${f.flipped ? 'scaleX(-1)' : ''}`,
              animationDuration: `${2.4 + (f.id % 3) * 0.5}s`,
            }}
          >
            <Fish hue={f.hue} />
          </div>
        </div>
      ))}

      <div className="uw-seabed">
        {weeds.map((w) => (
          <span
            key={w.id}
            className="uw-weed"
            style={{
              left: w.left,
              height: w.height,
              animationDuration: `${w.duration}s`,
              animationDelay: `${w.delay}s`,
            }}
          />
        ))}
      </div>
    </div>
  );
}
