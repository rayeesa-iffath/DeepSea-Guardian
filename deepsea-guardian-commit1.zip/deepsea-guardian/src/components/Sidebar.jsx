import { NavLink } from "react-router-dom";

const links = [
  { to: "/", label: "Dashboard" },
  { to: "/fleet", label: "Drone Fleet" },
  { to: "/alerts", label: "Alerts" },
];

export default function Sidebar() {
  return (
    <aside className="w-56 shrink-0 bg-slate-800 text-slate-200 min-h-[calc(100vh-4rem)] p-4">
      <ul className="space-y-2">
        {links.map((link) => (
          <li key={link.to}>
            <NavLink
              to={link.to}
              end={link.to === "/"}
              className={({ isActive }) =>
                `block rounded-lg px-3 py-2 text-sm transition-colors ${
                  isActive
                    ? "bg-cyan-500/20 text-cyan-300 font-medium"
                    : "hover:bg-slate-700"
                }`
              }
            >
              {link.label}
            </NavLink>
          </li>
        ))}
      </ul>
    </aside>
  );
}
