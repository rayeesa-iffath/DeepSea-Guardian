export default function Dashboard() {
  return (
    <div>
      <h2 className="text-xl font-semibold text-slate-800 mb-2">Dashboard</h2>
      <p className="text-slate-500 text-sm">
        Placeholder view — widgets and live data will be wired up in a later commit.
      </p>
    </div>
  );
}
