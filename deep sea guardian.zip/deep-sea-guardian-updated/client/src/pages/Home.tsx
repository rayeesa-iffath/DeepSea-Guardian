import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import Ferrofluid from '@/components/Ferrofluid';
import { Button } from '@/components/ui/button';
import { Waves, Zap, Map, Users, AlertCircle } from 'lucide-react';

const fadeInUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.3
    }
  }
};

export default function Home() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen text-foreground">
      {/* Hero Section with Ferrofluid Background */}
      <section className="relative h-screen overflow-hidden">
        <div className="absolute inset-0 z-0">
          <Ferrofluid
            colors={['#39ff8f', '#ffd166', '#2dd4bf']}
            speed={0.5}
            scale={1.0}
            turbulence={1}
            fluidity={0.1}
            rimWidth={0.2}
            sharpness={2.5}
            shimmer={1.5}
            glow={2}
            flowDirection="down"
            opacity={0.8}
            mouseInteraction={true}
            mouseStrength={1}
            mouseRadius={0.35}
          />
        </div>

        {/* Content Overlay */}
        <div className="relative z-10 h-full flex flex-col items-center justify-center px-4">
          <motion.div
            className="text-center max-w-4xl"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            <motion.h1
              variants={fadeInUp}
              className="text-5xl md:text-7xl font-bold mb-6 text-accent drop-shadow-lg"
            >
              DeepSea Guardian
            </motion.h1>

            <motion.p
              variants={fadeInUp}
              className="text-xl md:text-2xl mb-8 text-foreground/90 drop-shadow-md"
            >
              AI-Powered Ocean Intelligence Platform
            </motion.p>

            <motion.p
              variants={fadeInUp}
              className="text-lg md:text-xl mb-12 text-foreground/80 max-w-2xl drop-shadow-md"
            >
              Real-time monitoring of ocean pollution, biodiversity, and environmental threats.
              Empowering governments, NGOs, and researchers with actionable ocean conservation intelligence.
            </motion.p>

            <motion.div
              variants={fadeInUp}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Link href="/dashboard">
                <Button
                  size="lg"
                  className="bg-accent text-accent-foreground hover:bg-accent/90 neon-glow"
                >
                  <Zap className="mr-2 h-5 w-5" />
                  View Dashboard
                </Button>
              </Link>
              <Link href="/map">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-accent text-accent hover:bg-accent/10"
                >
                  <Map className="mr-2 h-5 w-5" />
                  Explore Map
                </Button>
              </Link>
            </motion.div>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <Waves className="h-6 w-6 text-accent" />
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-4 text-accent">
              Platform Features
            </h2>
            <p className="text-foreground/70 text-lg">
              Comprehensive ocean monitoring and conservation intelligence
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Zap,
                title: 'Real-Time Dashboard',
                description: 'Live metrics for water quality, coral health, plastic density, and marine species',
                href: '/dashboard'
              },
              {
                icon: Map,
                title: 'Interactive World Map',
                description: 'Clickable hotspots for pollution zones, illegal fishing, and protected areas',
                href: '/map'
              },
              {
                icon: Users,
                title: 'Species Recognition',
                description: 'AI-powered marine species identification with detailed biodiversity insights',
                href: '/species'
              },
              {
                icon: AlertCircle,
                title: 'Alert Center',
                description: 'Real-time conservation alerts with severity levels and timestamps',
                href: '/alerts'
              },
              {
                icon: Waves,
                title: 'Risk Prediction',
                description: 'Forecasted environmental damage trends and climate impact analysis',
                href: '/analytics'
              },
              {
                icon: Zap,
                title: 'Ocean Digital Twin',
                description: 'Advanced visualization of ocean health and predictive modeling',
                href: '/dashboard'
              }
            ].map((feature, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                viewport={{ once: true }}
                className="glass rounded-lg p-6 hover:shadow-lg hover:shadow-accent/30 transition-all duration-300"
              >
                <Link href={feature.href}>
                  <div className="cursor-pointer">
                    <feature.icon className="h-12 w-12 text-accent mb-4" />
                    <h3 className="text-xl font-semibold mb-2 text-foreground">
                      {feature.title}
                    </h3>
                    <p className="text-foreground/70">{feature.description}</p>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-card/50 border-t border-border">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto text-center"
        >
          <h2 className="text-4xl font-bold mb-6 text-accent">
            Join the Ocean Conservation Mission
          </h2>
          <p className="text-lg text-foreground/70 mb-8">
            Explore real-time ocean intelligence and contribute to global marine conservation efforts.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/dashboard">
              <Button
                size="lg"
                className="bg-accent text-accent-foreground hover:bg-accent/90 neon-glow"
              >
                Start Monitoring
              </Button>
            </Link>
            <Link href="/map">
              <Button
                size="lg"
                variant="outline"
                className="border-accent text-accent hover:bg-accent/10"
              >
                View Global Map
              </Button>
            </Link>
          </div>
        </motion.div>
      </section>
    </div>
  );
}
