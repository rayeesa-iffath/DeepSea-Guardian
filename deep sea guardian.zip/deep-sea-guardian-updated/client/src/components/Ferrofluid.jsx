import React, { useEffect, useRef } from 'react';
import { Renderer, Program, Mesh, Triangle } from 'ogl';
import './Ferrofluid.css';

const MAX_COLORS = 8;

const hexToRGB = hex => {
  const c = hex.replace('#', '').padEnd(6, '0');
  const r = parseInt(c.slice(0, 2), 16) / 255;
  const g = parseInt(c.slice(2, 4), 16) / 255;
  const b = parseInt(c.slice(4, 6), 16) / 255;
  return [r, g, b];
};

const prepColors = input => {
  const base = (input && input.length ? input : ['#00d9ff', '#ffd166', '#00f5d4']).slice(0, MAX_COLORS);
  const count = base.length;
  const arr = [];
  for (let i = 0; i < MAX_COLORS; i++) arr.push(hexToRGB(base[Math.min(i, base.length - 1)]));
  const avg = [0, 0, 0];
  for (let i = 0; i < count; i++) {
    avg[0] += arr[i][0];
    avg[1] += arr[i][1];
    avg[2] += arr[i][2];
  }
  avg[0] /= count;
  avg[1] /= count;
  avg[2] /= count;
  return { arr, count, avg };
};

const flowVec = d => {
  switch (d) {
    case 'up':
      return [0, 1];
    case 'down':
      return [0, -1];
    case 'left':
      return [-1, 0];
    case 'right':
      return [1, 0];
    default:
      return [0, -1];
  }
};

const vertex = `
attribute vec2 position;
attribute vec2 uv;
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position, 0.0, 1.0);
}
`;

const fragment = `
precision highp float;

uniform vec3  iResolution;
uniform vec2  iMouse;
uniform float iTime;

uniform vec3  uColor0;
uniform vec3  uColor1;
uniform vec3  uColor2;
uniform vec3  uColor3;
uniform vec3  uColor4;
uniform vec3  uColor5;
uniform vec3  uColor6;
uniform vec3  uColor7;
uniform int   uColorCount;

uniform vec3  uMouseColor;
uniform vec2  uFlow;
uniform float uSpeed;
uniform float uScale;
uniform float uTurbulence;
uniform float uFluidity;
uniform float uRimWidth;
uniform float uSharpness;
uniform float uShimmer;
uniform float uGlow;
uniform float uOpacity;
uniform float uMouseEnabled;
uniform float uMouseStrength;
uniform float uMouseRadius;

varying vec2 vUv;

#define PI 3.14159265

vec3 palette(float h) {
  int count = uColorCount;
  if (count < 1) count = 1;
  int idx = int(floor(clamp(h, 0.0, 0.999999) * float(count)));
  if (idx <= 0) return uColor0;
  if (idx == 1) return uColor1;
  if (idx == 2) return uColor2;
  if (idx == 3) return uColor3;
  if (idx == 4) return uColor4;
  if (idx == 5) return uColor5;
  if (idx == 6) return uColor6;
  return uColor7;
}

float hash(vec3 p3) {
  p3 = fract(p3 * 0.1031);
  p3 += dot(p3, p3.zyx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

float noise(vec2 p, float seed) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(
    mix(hash(vec3(i + vec2(0.0, 0.0), seed)), hash(vec3(i + vec2(1.0, 0.0), seed)), u.x),
    mix(hash(vec3(i + vec2(0.0, 1.0), seed)), hash(vec3(i + vec2(1.0, 1.0), seed)), u.x),
    u.y
  );
}

float fbm(vec2 p, float seed) {
  float val = 0.0;
  float amp = 0.5;
  mat2 rot = mat2(0.8, 0.6, -0.6, 0.8);
  vec2 uv = p * 0.05;
  for (int i = 0; i < 3; i++) {
    val += amp * noise(uv, seed);
    uv = rot * uv * 2.0;
    amp *= 0.5;
  }
  return val;
}

void main() {
  vec2 uv = vUv;
  vec2 p = uv * iResolution.xy;
  
  vec2 flowDir = normalize(uFlow);
  float flowAmount = fbm(p * 0.001 + iTime * uSpeed * 0.1, 0.0) * uTurbulence;
  p += flowDir * flowAmount * 50.0;
  
  float n = fbm(p * 0.001 + iTime * uSpeed * 0.05, iTime * 0.1);
  n = mix(n, fbm(p * 0.002 + iTime * uSpeed * 0.08, iTime * 0.15), uFluidity);
  
  if (uMouseEnabled > 0.5) {
    vec2 mousePos = iMouse / iResolution.xy;
    float dist = distance(uv, mousePos);
    if (dist < uMouseRadius) {
      float influence = (1.0 - dist / uMouseRadius) * uMouseStrength;
      n = mix(n, 1.0, influence);
    }
  }
  
  vec3 col = palette(n);
  
  float rim = smoothstep(uRimWidth + 0.1, uRimWidth, abs(n - 0.5) * 2.0);
  col = mix(col, col * 1.5, rim * uSharpness);
  
  float shimmerNoise = sin(n * 20.0 + iTime) * 0.5 + 0.5;
  col += vec3(shimmerNoise) * uShimmer * 0.1;
  
  col += col * uGlow * 0.2;
  
  gl_FragColor = vec4(col, uOpacity);
}
`;

export default function Ferrofluid({
  colors = ['#00d9ff', '#ffd166', '#00f5d4'],
  speed = 0.5,
  scale = 1.0,
  turbulence = 1,
  fluidity = 0.1,
  rimWidth = 0.2,
  sharpness = 2.5,
  shimmer = 1.5,
  glow = 2,
  flowDirection = 'down',
  opacity = 1,
  mouseInteraction = true,
  mouseStrength = 1,
  mouseRadius = 0.35
}) {
  const containerRef = useRef(null);
  const rendererRef = useRef(null);
  const mouseRef = useRef([0, 0]);

  useEffect(() => {
    if (!containerRef.current) return;

    const { arr: colorArr, count: colorCount, avg: avgColor } = prepColors(colors);
    const flowVec_ = flowVec(flowDirection);

    const renderer = new Renderer({
      width: window.innerWidth,
      height: window.innerHeight,
      dpr: 1
    });

    renderer.gl.canvas.style.display = 'block';
    containerRef.current.appendChild(renderer.gl.canvas);
    rendererRef.current = renderer;

    const geometry = new Triangle(renderer.gl);
    const program = new Program(renderer.gl, {
      vertex,
      fragment,
      uniforms: {
        iResolution: { value: [window.innerWidth, window.innerHeight, 1] },
        iMouse: { value: [0, 0] },
        iTime: { value: 0 },
        uColor0: { value: colorArr[0] },
        uColor1: { value: colorArr[1] },
        uColor2: { value: colorArr[2] },
        uColor3: { value: colorArr[3] },
        uColor4: { value: colorArr[4] },
        uColor5: { value: colorArr[5] },
        uColor6: { value: colorArr[6] },
        uColor7: { value: colorArr[7] },
        uColorCount: { value: colorCount },
        uMouseColor: { value: avgColor },
        uFlow: { value: flowVec_ },
        uSpeed: { value: speed },
        uScale: { value: scale },
        uTurbulence: { value: turbulence },
        uFluidity: { value: fluidity },
        uRimWidth: { value: rimWidth },
        uSharpness: { value: sharpness },
        uShimmer: { value: shimmer },
        uGlow: { value: glow },
        uOpacity: { value: opacity },
        uMouseEnabled: { value: mouseInteraction ? 1 : 0 },
        uMouseStrength: { value: mouseStrength },
        uMouseRadius: { value: mouseRadius }
      }
    });

    const mesh = new Mesh(renderer.gl, { geometry, program });

    let time = 0;
    const animate = () => {
      time += 0.016;
      program.uniforms.iTime.value = time;
      program.uniforms.iMouse.value = mouseRef.current;
      renderer.render({ scene: mesh });
      requestAnimationFrame(animate);
    };

    const handleMouseMove = e => {
      mouseRef.current = [e.clientX, window.innerHeight - e.clientY];
    };

    const handleResize = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;
      renderer.setSize(width, height);
      program.uniforms.iResolution.value = [width, height, 1];
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('resize', handleResize);

    animate();

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      containerRef.current?.removeChild(renderer.gl.canvas);
    };
  }, [colors, speed, scale, turbulence, fluidity, rimWidth, sharpness, shimmer, glow, flowDirection, opacity, mouseInteraction, mouseStrength, mouseRadius]);

  return <div ref={containerRef} className="ferrofluid-container" />;
}
