import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

// Mock data for charts
const trendData = [
  { month: 'Jan', pollution: 65, coralHealth: 72, riskIndex: 58 },
  { month: 'Feb', pollution: 72, coralHealth: 68, riskIndex: 65 },
  { month: 'Mar', pollution: 68, coralHealth: 65, riskIndex: 62 },
  { month: 'Apr', pollution: 78, coralHealth: 60, riskIndex: 72 },
  { month: 'May', pollution: 82, coralHealth: 55, riskIndex: 78 },
  { month: 'Jun', pollution: 85, coralHealth: 52, riskIndex: 82 },
  { month: 'Jul', pollution: 88, coralHealth: 48, riskIndex: 85 }
];

const climateImpactData = [
  { year: '2020', tempIncrease: 0.5, seaLevelRise: 3.2, acidification: 0.12 },
  { year: '2021', tempIncrease: 0.6, seaLevelRise: 3.5, acidification: 0.14 },
  { year: '2022', tempIncrease: 0.7, seaLevelRise: 3.8, acidification: 0.16 },
  { year: '2023', tempIncrease: 0.8, seaLevelRise: 4.1, acidification: 0.18 },
  { year: '2024', tempIncrease: 0.9, seaLevelRise: 4.4, acidification: 0.20 },
  { year: '2025', tempIncrease: 1.0, seaLevelRise: 4.7, acidification: 0.22 }
];

const forecastData = [
  { quarter: 'Q1 2024', predicted: 72, actual: 70 },
  { quarter: 'Q2 2024', predicted: 75, actual: 78 },
  { quarter: 'Q3 2024', predicted: 78, actual: 82 },
  { quarter: 'Q4 2024', predicted: 82, actual: null },
  { quarter: 'Q1 2025', predicted: 85, actual: null },
  { quarter: 'Q2 2025', predicted: 88, actual: null }
];

export default function Analytics() {
  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-accent mb-2">
            AI Risk Prediction Engine
          </h1>
          <p className="text-foreground/70 text-lg">
            Forecasted environmental damage trends and climate impact analysis
          </p>
        </motion.div>

        {/* Charts Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="space-y-8"
        >
          {/* Ocean Health Trends */}
          <motion.div variants={itemVariants}>
            <Card className="glass p-8">
              <h2 className="text-2xl font-bold text-accent mb-6">Ocean Health Trends</h2>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={trendData}>
                  <defs>
                    <linearGradient id="colorPollution" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ff4444" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#ff4444" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorHealth" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ffd166" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#ffd166" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1c4740" />
                  <XAxis dataKey="month" stroke="#7fc4ab" />
                  <YAxis stroke="#7fc4ab" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f2e28',
                      border: '1px solid #1c4740',
                      borderRadius: '8px'
                    }}
                    labelStyle={{ color: '#e4fff2' }}
                  />
                  <Legend />
                  <Area
                    type="monotone"
                    dataKey="pollution"
                    stroke="#ff4444"
                    fillOpacity={1}
                    fill="url(#colorPollution)"
                    name="Pollution Level"
                  />
                  <Area
                    type="monotone"
                    dataKey="coralHealth"
                    stroke="#ffd166"
                    fillOpacity={1}
                    fill="url(#colorHealth)"
                    name="Coral Health %"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </Card>
          </motion.div>

          {/* Climate Impact Forecast */}
          <motion.div variants={itemVariants}>
            <Card className="glass p-8">
              <h2 className="text-2xl font-bold text-accent mb-6">Climate Impact Forecast</h2>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={climateImpactData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1c4740" />
                  <XAxis dataKey="year" stroke="#7fc4ab" />
                  <YAxis stroke="#7fc4ab" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f2e28',
                      border: '1px solid #1c4740',
                      borderRadius: '8px'
                    }}
                    labelStyle={{ color: '#e4fff2' }}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="tempIncrease"
                    stroke="#ff6b6b"
                    strokeWidth={2}
                    name="Temp Increase (°C)"
                    dot={{ fill: '#ff6b6b', r: 4 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="seaLevelRise"
                    stroke="#39ff8f"
                    strokeWidth={2}
                    name="Sea Level Rise (cm)"
                    dot={{ fill: '#39ff8f', r: 4 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="acidification"
                    stroke="#ffd700"
                    strokeWidth={2}
                    name="Acidification (pH)"
                    dot={{ fill: '#ffd700', r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </Card>
          </motion.div>

          {/* Risk Index Forecast */}
          <motion.div variants={itemVariants}>
            <Card className="glass p-8">
              <h2 className="text-2xl font-bold text-accent mb-6">Risk Index Forecast</h2>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={forecastData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1c4740" />
                  <XAxis dataKey="quarter" stroke="#7fc4ab" />
                  <YAxis stroke="#7fc4ab" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f2e28',
                      border: '1px solid #1c4740',
                      borderRadius: '8px'
                    }}
                    labelStyle={{ color: '#e4fff2' }}
                  />
                  <Legend />
                  <Bar
                    dataKey="predicted"
                    fill="#39ff8f"
                    name="Predicted Risk"
                    radius={[8, 8, 0, 0]}
                  />
                  <Bar
                    dataKey="actual"
                    fill="#ffd166"
                    name="Actual Risk"
                    radius={[8, 8, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          </motion.div>

          {/* Key Insights */}
          <motion.div variants={itemVariants} className="grid md:grid-cols-2 gap-6">
            <Card className="glass p-6">
              <h3 className="text-xl font-bold text-accent mb-4">Key Predictions</h3>
              <ul className="space-y-3 text-foreground/80">
                <li className="flex items-start">
                  <span className="text-accent mr-3">•</span>
                  <span>Pollution levels expected to increase 15% by Q4 2024</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-3">•</span>
                  <span>Coral bleaching risk will peak during summer months</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-3">•</span>
                  <span>Ocean acidification continuing at accelerated rate</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-3">•</span>
                  <span>Marine species migration patterns shifting northward</span>
                </li>
              </ul>
            </Card>

            <Card className="glass p-6">
              <h3 className="text-xl font-bold text-accent mb-4">Recommended Actions</h3>
              <ul className="space-y-3 text-foreground/80">
                <li className="flex items-start">
                  <span className="text-secondary mr-3">→</span>
                  <span>Increase monitoring in high-risk pollution zones</span>
                </li>
                <li className="flex items-start">
                  <span className="text-secondary mr-3">→</span>
                  <span>Deploy additional conservation resources to coral reefs</span>
                </li>
                <li className="flex items-start">
                  <span className="text-secondary mr-3">→</span>
                  <span>Establish marine protected areas in migration corridors</span>
                </li>
                <li className="flex items-start">
                  <span className="text-secondary mr-3">→</span>
                  <span>Coordinate international ocean conservation initiatives</span>
                </li>
              </ul>
            </Card>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
