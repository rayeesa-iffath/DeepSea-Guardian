import alerts from "../data/alerts.json";

const levelColor = {
  high: "text-red-500",
  medium: "text-amber-500",
  low: "text-emerald-500",
};

export default function Alerts() {
  return (
    <div>
      <h2 className="text-xl font-semibold text-slate-800 mb-4">Alerts</h2>
      <ul className="space-y-2">
        {alerts.map((a) => (
          <li
            key={a.id}
            className="bg-white border border-slate-200 rounded-lg px-4 py-3 text-sm"
          >
            <span className={`font-medium uppercase text-xs ${levelColor[a.level]}`}>
              {a.level}
            </span>
            <p className="text-slate-700 mt-1">{a.message}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
