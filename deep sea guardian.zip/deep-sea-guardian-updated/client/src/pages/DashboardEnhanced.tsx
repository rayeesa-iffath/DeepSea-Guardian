import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Zap, Droplets, Fish, AlertTriangle, TrendingUp, Activity } from 'lucide-react';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
};

// Animated counter component
import { useRef } from 'react';
function AnimatedCounter({ target, duration = 1 }: { target: number; duration?: number }) {
  const [count, setCount] = useState(target);
  const prevTargetRef = useRef(target);

  useEffect(() => {
    const startVal = prevTargetRef.current;
    const endVal = target;
    if (startVal === endVal) return;

    let startTime: number;
    let animationId: number;

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / (duration * 1000), 1);

      setCount(Math.floor(startVal + (endVal - startVal) * progress));

      if (progress < 1) {
        animationId = requestAnimationFrame(animate);
      } else {
        prevTargetRef.current = endVal;
      }
    };

    animationId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationId);
  }, [target, duration]);

  useEffect(() => {
    prevTargetRef.current = target;
  }, []);

  return <span>{count}</span>;
}

export default function DashboardEnhanced() {
  const [metrics, setMetrics] = useState({
    waterQuality: 72,
    coralHealth: 58,
    plasticDensity: 82,
    marineSpecies: 1247,
    riskIndex: 68
  });

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics(prev => ({
        waterQuality: Math.max(50, prev.waterQuality + (Math.random() - 0.5) * 10),
        coralHealth: Math.max(30, prev.coralHealth + (Math.random() - 0.5) * 8),
        plasticDensity: Math.min(100, prev.plasticDensity + (Math.random() - 0.5) * 5),
        marineSpecies: prev.marineSpecies + Math.floor((Math.random() - 0.5) * 50),
        riskIndex: Math.max(40, Math.min(100, prev.riskIndex + (Math.random() - 0.5) * 6))
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const MetricCard = ({
    icon: Icon,
    title,
    value,
    unit,
    color,
    trend,
    description
  }: {
    icon: any;
    title: string;
    value: number;
    unit: string;
    color: string;
    trend: string;
    description: string;
  }) => (
    <motion.div variants={itemVariants}>
      <Card className="glass p-8 relative overflow-hidden group hover:shadow-lg hover:shadow-accent/30 transition-all duration-300">
        {/* Animated background gradient */}
        <div className={`absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity duration-300 bg-gradient-to-br ${color}`} />

        <div className="relative z-10">
          <div className="flex items-start justify-between mb-6">
            <div className={`p-3 rounded-lg bg-gradient-to-br ${color} text-white`}>
              <Icon className="h-6 w-6" />
            </div>
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="text-accent"
            >
              <TrendingUp className="h-5 w-5" />
            </motion.div>
          </div>

          <h3 className="text-lg font-semibold text-foreground mb-2">{title}</h3>

          <div className="mb-4">
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-bold text-accent">
                <AnimatedCounter target={Math.round(value)} />
              </span>
              <span className="text-foreground/60 text-sm">{unit}</span>
            </div>
          </div>

          {/* Progress bar */}
          <div className="mb-4 h-2 bg-card/50 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${value}%` }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className={`h-full bg-gradient-to-r ${color} rounded-full`}
            />
          </div>

          <div className="flex items-center justify-between">
            <p className="text-sm text-foreground/70">{description}</p>
            <span className={`text-xs px-2 py-1 rounded-full ${trend === 'up' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
              {trend === 'up' ? '↑' : '↓'} {Math.abs(Math.round((Math.random() - 0.5) * 10))}%
            </span>
          </div>
        </div>
      </Card>
    </motion.div>
  );

  return (
    <div className="min-h-screen pt-32 pb-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <h1 className="text-5xl md:text-6xl font-bold text-accent mb-2">
            Global Ocean Dashboard
          </h1>
          <p className="text-foreground/70 text-lg flex items-center gap-2">
            <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ duration: 2, repeat: Infinity }}>
              <Activity className="h-5 w-5 text-accent" />
            </motion.div>
            Real-time environmental metrics and ocean health indicators
          </p>
        </motion.div>

        {/* Main Metrics Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid md:grid-cols-2 lg:grid-cols-5 gap-6 mb-12"
        >
          <MetricCard
            icon={Droplets}
            title="Water Quality Index"
            value={metrics.waterQuality}
            unit="/100"
            color="from-emerald-500 to-teal-400"
            trend="up"
            description="Ocean water purity level"
          />
          <MetricCard
            icon={Fish}
            title="Coral Health"
            value={metrics.coralHealth}
            unit="%"
            color="from-orange-500 to-red-500"
            trend="down"
            description="Reef ecosystem status"
          />
          <MetricCard
            icon={AlertTriangle}
            title="Plastic Density"
            value={metrics.plasticDensity}
            unit="mg/km²"
            color="from-red-500 to-orange-500"
            trend="up"
            description="Ocean plastic pollution"
          />
          <MetricCard
            icon={Zap}
            title="Marine Species"
            value={metrics.marineSpecies}
            unit="count"
            color="from-amber-400 to-emerald-500"
            trend="up"
            description="Tracked biodiversity"
          />
          <MetricCard
            icon={TrendingUp}
            title="Risk Index"
            value={metrics.riskIndex}
            unit="/100"
            color="from-yellow-500 to-orange-500"
            trend="up"
            description="Environmental threat level"
          />
        </motion.div>

        {/* Live Status Section */}
        <motion.div
          variants={itemVariants}
          initial="hidden"
          animate="visible"
          transition={{ delay: 0.8 }}
        >
          <Card className="glass p-8 mb-12">
            <h2 className="text-2xl font-bold text-accent mb-6 flex items-center gap-2">
              <motion.div
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="w-3 h-3 rounded-full bg-accent"
              />
              Live Status
            </h2>

            <div className="grid md:grid-cols-3 gap-6">
              {[
                { label: 'Active Monitoring Zones', value: '12', status: 'active' },
                { label: 'Critical Alerts', value: '3', status: 'warning' },
                { label: 'Protected Areas', value: '8', status: 'safe' }
              ].map((item, idx) => (
                <motion.div
                  key={idx}
                  whileHover={{ scale: 1.05 }}
                  className="p-6 rounded-lg bg-card/50 border border-border hover:border-accent/50 transition-all"
                >
                  <p className="text-foreground/70 text-sm mb-2">{item.label}</p>
                  <div className="flex items-baseline gap-3">
                    <span className="text-3xl font-bold text-accent">{item.value}</span>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      item.status === 'active' ? 'bg-accent/20 text-accent' :
                      item.status === 'warning' ? 'bg-red-500/20 text-red-400' :
                      'bg-green-500/20 text-green-400'
                    }`}>
                      {item.status.toUpperCase()}
                    </span>
                  </div>
                </motion.div>
              ))}
            </div>
          </Card>
        </motion.div>

        {/* Detailed Insights */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          transition={{ delay: 1 }}
          className="grid md:grid-cols-2 gap-6"
        >
          <motion.div variants={itemVariants}>
            <Card className="glass p-8 h-full">
              <h3 className="text-xl font-bold text-accent mb-4">Key Observations</h3>
              <ul className="space-y-3 text-foreground/80">
                <li className="flex items-start gap-3">
                  <span className="text-accent mt-1">•</span>
                  <span>Water quality has improved by 8% in the North Atlantic region</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-accent mt-1">•</span>
                  <span>Coral bleaching risk elevated in tropical zones</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-accent mt-1">•</span>
                  <span>Marine species migration patterns shifting northward</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-accent mt-1">•</span>
                  <span>Plastic accumulation increasing in gyre regions</span>
                </li>
              </ul>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card className="glass p-8 h-full">
              <h3 className="text-xl font-bold text-accent mb-4">Recommended Actions</h3>
              <ul className="space-y-3 text-foreground/80">
                <li className="flex items-start gap-3">
                  <span className="text-secondary mt-1">→</span>
                  <span>Increase monitoring frequency in high-risk zones</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-secondary mt-1">→</span>
                  <span>Deploy additional conservation resources to coral reefs</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-secondary mt-1">→</span>
                  <span>Coordinate international ocean cleanup initiatives</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-secondary mt-1">→</span>
                  <span>Establish new marine protected areas in migration corridors</span>
                </li>
              </ul>
            </Card>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
