# DeepSea Guardian — Commit 1: Base Setup & Scaffolding

This commit covers only:

- React + Vite + Tailwind repository initialized
- Routing set up (`react-router-dom`) with a basic layout shell (Navbar + Sidebar)
- Dummy JSON data files added under `src/data/` (drones, alerts, species)

Pages (`Dashboard`, `Fleet`, `Alerts`) are intentionally minimal placeholders that
just prove routing + data loading work — full UI/features come in later commits.

## Run it
```
npm install
npm run dev
```
