import { useState } from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { AlertTriangle, Zap, MapPin, Clock, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,
      delayChildren: 0.2
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.4 } }
};

// Mock alert data
const alertsData = [
  {
    id: 1,
    type: 'Pollution Spike',
    location: 'North Atlantic - 45.2°N, 52.3°W',
    severity: 'critical',
    timestamp: '2 minutes ago',
    description: 'Hazardous chemical discharge detected. Immediate action required.',
    affectedArea: '125 km²',
    status: 'Active'
  },
  {
    id: 2,
    type: 'Illegal Fishing Detection',
    location: 'South Pacific - 18.5°S, 165.2°E',
    severity: 'critical',
    timestamp: '15 minutes ago',
    description: 'Unauthorized fishing vessel detected in protected zone.',
    affectedArea: '45 km²',
    status: 'Active'
  },
  {
    id: 3,
    type: 'Coral Bleaching Alert',
    location: 'Great Barrier Reef - 16.2°S, 145.8°E',
    severity: 'warning',
    timestamp: '1 hour ago',
    description: 'Elevated water temperature causing coral stress.',
    affectedArea: '850 km²',
    status: 'Monitoring'
  },
  {
    id: 4,
    type: 'Oil Spill Detection',
    location: 'Gulf of Mexico - 27.5°N, 89.2°W',
    severity: 'critical',
    timestamp: '3 hours ago',
    description: 'Significant oil slick detected. Environmental impact assessment underway.',
    affectedArea: '320 km²',
    status: 'Escalating'
  },
  {
    id: 5,
    type: 'Plastic Accumulation',
    location: 'North Pacific Gyre - 35.2°N, 135.8°W',
    severity: 'warning',
    timestamp: '4 hours ago',
    description: 'Microplastic concentration exceeds safe levels.',
    affectedArea: '2500 km²',
    status: 'Monitoring'
  },
  {
    id: 6,
    type: 'Marine Species Mortality',
    location: 'Baltic Sea - 55.3°N, 18.5°E',
    severity: 'warning',
    timestamp: '6 hours ago',
    description: 'Unusual mortality event in marine mammal population detected.',
    affectedArea: '180 km²',
    status: 'Investigating'
  }
];

export default function AlertCenter() {
  const [filter, setFilter] = useState<'all' | 'critical' | 'warning'>('all');
  const [expandedAlert, setExpandedAlert] = useState<number | null>(null);

  const filteredAlerts = alertsData.filter(alert =>
    filter === 'all' ? true : alert.severity === filter
  );

  const getSeverityColor = (severity: string) => {
    return severity === 'critical' ? 'badge-critical' : 'badge-warning';
  };

  const getSeverityIcon = (severity: string) => {
    return severity === 'critical' ? (
      <AlertTriangle className="h-5 w-5 text-red-400" />
    ) : (
      <Zap className="h-5 w-5 text-yellow-400" />
    );
  };

  const stats = {
    critical: alertsData.filter(a => a.severity === 'critical').length,
    warning: alertsData.filter(a => a.severity === 'warning').length,
    total: alertsData.length
  };

  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-accent mb-2">
            Emergency Alert Center
          </h1>
          <p className="text-foreground/70 text-lg">
            Real-time conservation alerts and environmental threat monitoring
          </p>
        </motion.div>

        {/* Stats Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="grid md:grid-cols-3 gap-6 mb-12"
        >
          <Card className="glass p-6 text-center">
            <div className="stat-counter text-4xl mb-2 text-red-400">
              {stats.critical}
            </div>
            <p className="text-foreground/70">Critical Alerts</p>
          </Card>
          <Card className="glass p-6 text-center">
            <div className="stat-counter text-4xl mb-2 text-yellow-400">
              {stats.warning}
            </div>
            <p className="text-foreground/70">Warning Alerts</p>
          </Card>
          <Card className="glass p-6 text-center">
            <div className="stat-counter text-4xl mb-2 text-accent">
              {stats.total}
            </div>
            <p className="text-foreground/70">Total Active Alerts</p>
          </Card>
        </motion.div>

        {/* Filter Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8 flex flex-wrap gap-3"
        >
          <Button
            onClick={() => setFilter('all')}
            variant={filter === 'all' ? 'default' : 'outline'}
            className={filter === 'all' ? 'bg-accent text-accent-foreground' : 'border-accent text-accent'}
          >
            <Filter className="mr-2 h-4 w-4" />
            All Alerts
          </Button>
          <Button
            onClick={() => setFilter('critical')}
            variant={filter === 'critical' ? 'default' : 'outline'}
            className={filter === 'critical' ? 'bg-red-500 text-white' : 'border-red-500 text-red-400'}
          >
            <AlertTriangle className="mr-2 h-4 w-4" />
            Critical Only
          </Button>
          <Button
            onClick={() => setFilter('warning')}
            variant={filter === 'warning' ? 'default' : 'outline'}
            className={filter === 'warning' ? 'bg-yellow-500 text-white' : 'border-yellow-500 text-yellow-400'}
          >
            <Zap className="mr-2 h-4 w-4" />
            Warnings Only
          </Button>
        </motion.div>

        {/* Alerts List */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="space-y-4"
        >
          {filteredAlerts.map((alert) => (
            <motion.div
              key={alert.id}
              variants={itemVariants}
              onClick={() => setExpandedAlert(expandedAlert === alert.id ? null : alert.id)}
              className="cursor-pointer"
            >
              <Card className={`glass p-6 hover:shadow-lg transition-all duration-300 ${
                alert.severity === 'critical'
                  ? 'hover:shadow-red-500/30 border-red-500/30'
                  : 'hover:shadow-yellow-500/30 border-yellow-500/30'
              }`}>
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4 flex-1">
                    {getSeverityIcon(alert.severity)}
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold text-foreground">
                          {alert.type}
                        </h3>
                        <span className={`text-xs px-3 py-1 rounded-full ${getSeverityColor(alert.severity)}`}>
                          {alert.severity.toUpperCase()}
                        </span>
                        <span className="text-xs px-3 py-1 rounded-full bg-accent/20 text-accent">
                          {alert.status}
                        </span>
                      </div>

                      <div className="space-y-2 text-sm text-foreground/70">
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-accent" />
                          <span>{alert.location}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-accent" />
                          <span>{alert.timestamp}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <motion.div
                    animate={{ rotate: expandedAlert === alert.id ? 180 : 0 }}
                    transition={{ duration: 0.3 }}
                    className="text-accent ml-4"
                  >
                    <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                    </svg>
                  </motion.div>
                </div>

                {/* Expanded Details */}
                {expandedAlert === alert.id && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3 }}
                    className="mt-6 pt-6 border-t border-border space-y-4"
                  >
                    <div>
                      <p className="text-accent font-semibold mb-2">Description</p>
                      <p className="text-foreground/70">{alert.description}</p>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-accent font-semibold mb-2">Affected Area</p>
                        <p className="text-foreground/70">{alert.affectedArea}</p>
                      </div>
                      <div>
                        <p className="text-accent font-semibold mb-2">Current Status</p>
                        <p className="text-foreground/70">{alert.status}</p>
                      </div>
                    </div>

                    <div className="pt-4 flex gap-3">
                      <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
                        View on Map
                      </Button>
                      <Button variant="outline" className="border-accent text-accent hover:bg-accent/10">
                        More Details
                      </Button>
                    </div>
                  </motion.div>
                )}
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {filteredAlerts.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <p className="text-foreground/70 text-lg">No alerts found for the selected filter.</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
